# AgendaSalud - Sistema de Gestión de Citas Médicas
## Dispensario "La Dolorosa" - Grupo 2 - Ingeniería de Software 1

### 🚀 EJECUCIÓN RÁPIDA EN VS CODE (1 CLIC)

**Opción 1 - Doble clic (Windows):**
1. Abre la carpeta `AgendaSalud_Python_VSCode` en VS Code
2. Haz doble clic en `run.bat` o ejecuta en terminal: `python main.py`

**Opción 2 - Terminal VS Code:**
```bash
python main.py
```

**El programa hace TODO automáticamente:**
- ✓ Instala librerías faltantes automáticamente (tkcalendar)
- ✓ Crea base de datos `agendasalud.db` automáticamente
- ✓ Crea usuarios de prueba automáticamente
- ✓ Abre ventana de login

### 👤 USUARIOS DE PRUEBA

| Usuario | Contraseña | Rol |
|---------|------------|-----|
| admin | Admin123* | Administrativo (acceso total) |
| medico1 | Medico123* | Médico (solo panel) |

### 📋 FUNCIONALIDADES IMPLEMENTADAS (Según Rúbrica)

- **RF-01:** Registro de pacientes con validación cédula ecuatoriana
- **RF-02:** Registro de médicos y horarios
- **RF-03:** Gestión de especialidades
- **RF-04:** Agendar cita con validación anti-cruces
- **RF-05:** Reprogramar cita
- **RF-06:** Cancelar cita y liberar horario
- **RF-07:** Consulta disponibilidad por médico/fecha
- **RF-08:** Panel citas del día filtrable
- **RF-09:** Búsqueda pacientes por cédula/nombre
- **RF-10:** Confirmación visual imprimible
- **RF-11:** Autenticación por roles

### 🛠️ SOLUCIÓN DE PROBLEMAS

**Si sale error de tkinter:**
- En Windows: Ya viene con Python
- En Linux: `sudo apt-get install python3-tk`

**Si no abre ventana:**
- Verifica que ejecutas `python main.py` desde terminal integrada de VS Code
- Cierra otros programas que usen puerto

**Si error de permisos:**
- Ejecuta VS Code como administrador
- O usa: `pip install tkcalendar --user`

### 📁 ARCHIVOS GENERADOS

- `agendasalud.db` - Base de datos SQLite (se crea automáticamente)
- `main.py` - Código principal (único archivo necesario)

### 👥 GRUPO 2

- López, Sara - Líder y Analista
- Vásquez, Víctor - Desarrollador
- Yunga, Carmen - Documentación
- Vera, John - QA

Universidad Agraria del Ecuador - 2026
