#!/bin/bash
echo "================================================================"
echo "AgendaSalud - Dispensario La Dolorosa - Iniciando..."
echo "================================================================"
echo "Verificando Python..."
python3 --version
echo ""
echo "Instalando dependencias automaticamente..."
python3 -m pip install --upgrade pip --quiet
python3 -m pip install tkcalendar --quiet
echo ""
echo "Ejecutando AgendaSalud..."
echo ""
python3 main.py
